package com.sample;

/**
 * @author jacki
 */
public enum Gender {
    MALE, FEMALE
}
