/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.List;
import java.util.Map;
import static java.util.Map.entry;
import java.util.Set;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        OuterClass outc = new OuterClass();
        outc.outerMethod();        
    }
    
}// MainClass 結束

//-------------------------------------

// 外部類別
class OuterClass{
    
    private int a = 1;
    private static int b = 2;
    
    public void outerMethod(){
        // 建立內部類別物件
        InnerClass inc = new InnerClass();
        inc.display();
        System.out.println("inc.c：" + inc.c);
    }
    
    // Member Class 一般內部類別
    private class InnerClass{
        // 屬性
        private int c = 3;
        // private static int d = 4;  // Member Class 沒有 static 類別成員 
        
        // 建構子
        public InnerClass(){
            System.out.println("InnerClass()...");
        }
        
        // 方法
        public void display(){
            System.out.println("OuterClass a：" + a);
            System.out.println("OuterClass b：" + b);
            System.out.println("InnerClass c：" + c);
        }
        
    }
    
}


