/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        try{
            // 有可能發生錯誤的程式寫在 try 區塊內
            System.out.print("輸入被除數 a=");
            int a = scanner.nextInt();
            System.out.print("輸入除數 b=");
            int b = scanner.nextInt();
            int c = cal(a, b);
            System.out.printf("%d / %d = %d%n", a, b, c);
        } catch(InputMismatchException ex){  // 捕捉對應的例外型別的錯誤
            System.out.println("[錯誤]事情大條了，輸入的資料格式錯誤!");
        } catch(ArithmeticException ex){
            System.out.println("[錯誤]" + ex);
            System.out.println("[訊息]" + ex.getMessage());
        } finally{
            System.out.println("finally...");
        }
        System.out.println("結束!");        
    }

    private static int cal(int a, int b) {
        return a / b;
    }
    
}
