/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.TreeSet;

/**
 *
 * @author User
 */
public class ComparableDemo {

    public static void main(String[] args) {

        TreeSet<String> strSet = new TreeSet();
        strSet.add("一");   // \u4e00
        strSet.add("二");   // \u4e8c
        strSet.add("三");   // \u4e09
        strSet.add("四");   // \u56db
        strSet.add("五");   // \u4e94
        System.out.println("strSet：" + strSet);

        TreeSet<Student> students = new TreeSet();
        students.add(new Student("Lisa", 1, 3.8));
        students.add(new Student("John", 8, 3.9));
        students.add(new Student("Amy", 5, 3.7));
        students.add(new Student("George", 2, 3.4));
        students.add(new Student("Thomas", 6, 3.5));
        System.out.println(students);
        

    }
}
