/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
// 單一 class 只能實作一次 Comparable 介面，所以整能提供單一方式的排序，可用於 TreeSet 和 TreeMap 
public class Student implements Comparable<Student>{
    private String name; 
    private long id; 
    private double gpa;   // 學科成績平均績點

    public Student(String name, long id, double gpa) {
        this.name = name;
        this.id = id;
        this.gpa = gpa;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return name + "\t" + id + "\t" + gpa ;
    }

    // Comparable 實作 compareTo() 方法，比較自己(this) 和方法參數物件(o)
    // 只能提供一種排序規則
    @Override
    public int compareTo(Student o) {
//        if(this.id > o.getId()){
//            return 1;
//        }else if(this.id == o.getId()){
//            return 0;
//        }else{
//            return -1;
//        }

        // 先將 int 裝箱(int -> Long)，再呼叫 Long 的 compareTo() 比較大小
        // return Long.valueOf(this.id).compareTo(o.getId());
        
        // return this.name.compareTo(o.getName());
        
        return Double.valueOf(this.gpa).compareTo(o.getGpa()) * -1;
    }
    
    
    
    
}
