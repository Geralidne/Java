/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author User
 */
public class ComparatorDemo {
    
    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList();
        students.add(new Student("Lisa", 1, 3.8));
        students.add(new Student("John", 8, 3.9));
        students.add(new Student("Amy", 5, 3.7));
        students.add(new Student("George", 2, 3.4));
        students.add(new Student("Thomas", 6, 3.5));
        display(students);
        
        System.out.println("依 name 排序：");
        students.sort(new StudentSortName());
        display(students);
        
        System.out.println("依 id 排序：");
        students.sort(new StudentSortId());
        display(students);
        
        System.out.println("使用 Collections.sotr() 排序：");
        Collections.sort(students);  // 沒有指定排序規則，用 Student 類別內的 compareTo() 規則排序
        display(students);
        
        Collections.sort(students, new StudentSortId());  // 指定排序規則
        display(students);
        
        
        
        
    } // main() 結束
    
    private static void display(ArrayList<Student> students){
        for (Student s : students){
            System.out.println(s);
        }
        System.out.println("---------------------------");
    }
    
    // 用內部類別定義 id 排序規則
    private static class StudentSortId implements Comparator<Student>{

        @Override
        public int compare(Student o1, Student o2) {
            return Long.valueOf(o1.getId()).compareTo(o2.getId());
        }        
    }    
    
}
