/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
// 自訂例外型別，必須繼承一個例外父類別
public class MyException extends Exception{
    
    // 屬性
    private int errNum;
    
    // 建構子
    public MyException(int errNum, String message) {
        super(message);
        this.errNum = errNum;
    }
    
    // 方法
    // 重新定義 toString()
    @Override
    public String toString() {
        return "系統發生錯誤，代碼 " + errNum + "，請將錯誤代碼告知系統管理員";
    }
    
    
}
