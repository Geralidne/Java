package com.sample;

/**
 * @author jacki
 */
public enum Role {
    // 員工 經理 行政人員
    STAFF, MANAGER, EXECUTIVE    
}
