/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

/**
 *
 * @author User
 */
public class MapDemo {
    
    public static void main(String[] args) {
        HashMap<String, String> map = new HashMap();
        map.put("A01", "小明");
        map.put("D03", "Amy");
        map.put("B07", "Jason");
        map.put("D01", "小花");
        map.put("C05", "Lisa");
        System.out.println(map);
        
        map.put("A01", "大明");
        System.out.println(map);  // key 不可以重複，若 key 相同，新的 value 取代舊的 value 
        
        // 取出資料 get(key)
        System.out.println("A05：" + map.get("A05"));   // 若 key 不存在時回傳 null
        System.out.println("B07：" + map.get("B07"));
        System.out.println("--------------------------");

        // 取出所有的值
        Collection<String> values = map.values();
        for(String v : values){
            System.out.println(v);
        }
        System.out.println("--------------------------");
        
        // 取出 MAP 所有的資料
        // 1. 先用 keySet() 取出 Map 中所有的 key，放到 Set 集合中
        Set<String> keys = map.keySet();
        System.out.println("keys：" + keys);
        
        System.out.println("ID\tName");
        System.out.println("--------------------");
        
        // 2. 用迴圈取出 Set 集合中的 key，以 key 取 Map 集合中的 value
        for(String key : keys){
            System.out.println(key + "\t" + map.get(key));
        }
        
    }
}
