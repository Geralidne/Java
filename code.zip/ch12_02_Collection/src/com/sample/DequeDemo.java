/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.ArrayDeque;
import java.util.Iterator;

/**
 *
 * @author User
 */
public class DequeDemo {
    
    public static void main(String[] args) {
        System.out.println("Queue 先進先出 FIFO");
        ArrayDeque<String> fifo = new ArrayDeque();
        fifo.add("Kiwi");
        fifo.add("Apple");
        fifo.add("Orange");
        fifo.add("Banana");
        fifo.add("Apple");
        System.out.println("fifo：" + fifo);
        // fifo 取出不移除
        System.out.println("fifo.peek()：" + fifo.peek());
        System.out.println("fifo：" + fifo);
        // fifo 取出並移除
        System.out.println("fifo.remove()：" + fifo.remove());
        System.out.println("fifo：" + fifo);
        System.out.println("fifo.remove(\"banana\")：" + fifo.remove("Banana"));
        System.out.println("fifo：" + fifo);
        System.out.println("------------------------");
        
        System.out.println("Stack 後進先出 FILO");
        ArrayDeque<String> lifo = new ArrayDeque();
        lifo.push("Kiwi");
        lifo.push("Apple");
        lifo.push("Orange");
        lifo.push("Banana");
        lifo.push("Apple");
        System.out.println("lifo：" + lifo);
        
        // 使用迭代器
        Iterator<String> iterator = lifo.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("-------------------------");
        
        // lifo 取出並移除
        while(lifo.size() > 0){
            System.out.println("lifo.pop()：" + lifo.pop());
        }
        System.out.println("-------------------------");
        System.out.println("lifo.isEmpty()：" + lifo.isEmpty());
        System.out.println("lifo：" + lifo);
    }
}
