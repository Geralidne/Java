/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.List;
import java.util.Map;
import static java.util.Map.entry;
import java.util.Set;

/**
 *
 * @author User
 */
public class OfDemo {

    public static void main(String[] args) {
        // Java 9 提供靜態工廠方法 of() 建立不可變(immutable)的集合
        List<String> list1 = List.of("A", "B", "C");
        // list1.add("D");   // UnsupportedOperationException 不可以改變集合
        System.out.println("list1：" + list1);

        List<String> list2 = List.of("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K");
        System.out.println("list2：" + list2);
        System.out.println("-------------------");

        Set<String> set1 = Set.of("A", "B", "C");
        //set1.add("D");   // UnsupportedOperationException 不可以改變集合        
        System.out.println("set1：" + set1);

        // Set<String> set2 = Set.of("A", "B", "C", "B");  // IllegalArgumentException: duplicate element: B 新增時不可放重複的元素
        Set<String> set2 = Set.of("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K");
        System.out.println("set2：" + set2);
        System.out.println("-------------------");

        Map<String, Integer> map1 = Map.of("A", 1, "B", 2, "C", 3);
        // map1.put("D", 4);  // UnsupportedOperationException 不可以改變集合  
        System.out.println("map1：" + map1);

        // Map 用 of() 建立的資料最多 10 組
        // Map<String, Integer> map2 = Map.of("A", 1, "B", 2, "C", 3, "D", 4, "E", 5, "F", 6, "G", 7, "H", 8, "I", 9, "J", 10, "K", 11);
        
        // 若要建立超過 10 組資料使用 Map.ofEntries()
        Map<String, Integer> map2 = Map.ofEntries(
                entry("A", 1),
                entry("B", 2),
                entry("C", 3),
                entry("D", 4),
                entry("E", 5),
                entry("F", 6),
                entry("G", 7),
                entry("H", 8),
                entry("I", 9),
                entry("J", 10),
                entry("K", 11));
        System.out.println("map2：" + map2);
        // map2.put("L", 12);   // UnsupportedOperationException 不可以改變集合    
    }
}
