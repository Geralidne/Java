/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.HashSet;
import java.util.Random;
import java.util.TreeSet;

/**
 *
 * @author User
 */
public class SetDemo {
    
    public static void main(String[] args) {
        Random random = new Random();
        
        HashSet<Integer> hashSet = new HashSet();
        while(hashSet.size() < 6){
            int num = random.nextInt(49) + 1;
            System.out.printf("加入 %d -> %b%n", num, hashSet.add(num));
        }
        System.out.println("下注號碼：" + hashSet);
        
        TreeSet<Integer> treeSet = new TreeSet();
        while(treeSet.size() < 6){
            treeSet.add(random.nextInt(49) + 1);
        }
        System.out.println("開獎號碼：" + treeSet);
        
        System.out.println("是否全中：" + treeSet.containsAll(hashSet));
        
        treeSet.retainAll(hashSet);
        System.out.println("恭喜你，中了：" + treeSet);
        
    }
}
