/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample.packagea;

/**
 *
 * @author User
 */
public class B {
    
    // 方法
    public void display(){
        System.out.println("Class B...");
        // 建立類別 A 物件，可以操作的成員有哪些?
        A a = new A();
        // System.out.println("-a.w：" + a.w);
        System.out.println(" a.x：" + a.x);
        System.out.println("#a.y：" + a.y);
        System.out.println("+a.z：" + a.z);
    }
    
}
