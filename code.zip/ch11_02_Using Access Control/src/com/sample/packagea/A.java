/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample.packagea;

/**
 *
 * @author User
 */
public class A {
    
    // 屬性
    private int w = 1;
    int x = 2;
    protected int y = 3;
    public int z = 4;
    
    // 方法
    public void display(){
        System.out.println("Class A...");
        System.out.println("-w：" + w);
        System.out.println(" x：" + x);
        System.out.println("#y：" + y);
        System.out.println("+z：" + z);
    } 
    
    
}
