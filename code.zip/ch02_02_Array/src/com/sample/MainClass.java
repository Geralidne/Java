/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.Arrays;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // 宣告、實作、初始化一維陣列(All in one line)
        // 型別[] 陣列名稱 = {元素1, 元素2, 元素3, ...}
        int[] ages = {25, 47, 38};
        // 直接使用 print() 看不到陣列內容
        System.out.println("ages：" + ages); 
        // 使用 Arrays 類別中 toString() 顯示陣列內容
        System.out.println("ages：" + Arrays.toString(ages));
        System.out.println("-------------");
        
        // 取值
        // 陣列名稱[索引值]，索引值從 0 開始
        System.out.println("ages[0]：" + ages[0]);
        System.out.println("ages[1]：" + ages[1]);
        System.out.println("ages[2]：" + ages[2]);
        System.out.println("--------------");
        
        System.out.println("ages 的陣列長度：" + ages.length);
        
        // 使用一般 for 迴圈
        for(int i=0; i<ages.length; i++){
             System.out.println("ages[" + i + "]：" + ages[i]);
        }
        System.out.println("--------------");
        
        // 修改/設值
        // 陣列名稱[索引值] = 值
        ages[1] = 66;
        
        // 使用增強型 for 迴圈
        for(int i : ages){
            System.out.printf("%3d", i);
        }
        System.out.println("\n--------------");
        
        // 宣告、實作一維陣列
        // 宣告一維陣列：型別[] 陣列名稱;
        // 實作一維陣列：陣列名稱 = new 型別[陣列長度];  // 陣列長度一定要宣告，陣列實作後長度不可以修改
        // --------------------------------------
        // 宣告、實作一維陣列：型別[] 陣列名稱 = new 型別[陣列長度];
        // --------------------------------------
        String[] names = new String[3];
        System.out.println("先觀察陣列內容：");
        System.out.println("names[0]：" + names[0]);
        System.out.println("names[1]：" + names[1]);
        System.out.println("names[2]：" + names[2]);
        
        names[0] = "Java";
        names[1] = "Python";
        names[2] = "MySQL";
        
        for(String s : names){
            System.out.printf("%-8s|", s);
        }
        System.out.println("\n--------------");
        
        // 陣列中放入自訂類別建立的物件
        // 觀察【寫法一】與【寫法二】陣列中的內容
        // 【寫法一】
        // Book[] books = {new Book(), new Book(), new Book()};
        // System.out.println(Arrays.toString(books)); // [com.sample.Book@735b5592, com.sample.Book@58651fd0, com.sample.Book@4520ebad]
        
        // 【寫法二】
        Book[] books = new Book[3];
        System.out.println(Arrays.toString(books));// [null, null, null]
        books[0] = new Book();
        books[1] = new Book();
        books[2] = new Book();
        System.out.println(Arrays.toString(books));// [com.sample.Book@735b5592, com.sample.Book@58651fd0, com.sample.Book@4520ebad]
        
        // 指定 books 陣列中 Book 物件的值
        books[0].name = "Java SE 11";
        books[0].price = 700;
        
        books[1].name = "Python 3.9";
        books[1].price = 600;
        
        books[2].name = "Android 13";
        books[2].price = 800;
       
        // 取出 books 陣列中 Book 物件的值
        for(Book book : books){
            System.out.printf("Name：%s，Price：%d%n", book.name, book.price);
        }
        
        System.out.println("-------------------");
        
        // int[] test1 = new int[];  // new int[陣列長度一定要宣告]
        int test2[] = new int[3];
        int []test3 = new int[3];
        // int[] test4 = new int[2]{5, 10};   // new int[陣列長度不需要宣告]{5, 10}
        int[] test5 = new int[]{1, 3, 5}; 
        int[] test6 = new int[]{};   // 同 new int[0]，陣列長度是 0
        int[] test7;   // 錯誤寫法，all in  one line --> 不可以分開宣告
        // test7 = {2, 4, 6} ;
        test7 = new int[]{2, 4, 7};  // 正確寫法
        //-------------------------------------------------
        
        // 宣告多維陣列
        // 二維陣列長度相同
        // int[][] ids = {{11, 12}, {21, 22}, {31, 32}};
        
        // 二維陣列長度不相同
        int[][] ids = {{11, 12, 13}, {21, 22}, {31, 32, 33, 34, 35}};
        
        System.out.println("ids 陣列長度：" + ids.length);
        System.out.println("ids[0] 陣列長度：" + ids[0].length);
        System.out.println("ids[1] 陣列長度：" + ids[1].length);
        System.out.println("ids[2] 陣列長度：" + ids[2].length);
        // 查看一維陣列內容：Arrays.toString()
        System.out.println(Arrays.toString(ids));
        // 查看二維陣列內容：Arrays.deepToString()
        System.out.println(Arrays.deepToString(ids));
        System.out.println("---------");
        
        // 取值
        System.out.println("ids[0][1]：" + ids[0][1]);
        System.out.println("ids[2][0]：" + ids[2][0]);
        System.out.println("---------");
        
        // 一般 for 迴圈
        // 外迴圈抓陣列 ids[0]、ids[1]、ids[2]
        for(int i=0; i<ids.length; i++){
            // 內迴圈抓 ids[i] 中的值 ids[i][0]、ids[i][1]
            for(int j=0; j<ids[i].length; j++){
                System.out.printf("%d | ", ids[i][j]);
            }
            System.out.println();   // 內迴圈執行完換行
        }
        System.out.println("---------");
        
        // 增強型 for 迴圈
        for(int[] temp : ids){
            for(int i : temp){
                System.out.printf("%d | ", i);
            }
            System.out.println();
        }
        System.out.println("---------");
        
        // 二維陣列長度相同
        int[][] test8 = new int[3][2];
        
        // 二維陣列長度相同
        int[][] test9 = new int[3][];  // 第二個 [] 可以留空白
        test9[0] = new int[3];
        test9[0][0] = 11;
        test9[0][1] = 12;
        test9[0][2] = 13;
        
        test9[1] = new int[2];
        
        test9[2] = new int[]{31, 32, 33, 34, 35};
        System.out.println(Arrays.deepToString(test9));
        System.out.println("---------");
        
        // int[][] testA = new int[][];   // 第一個 [] 不可以空白
        int[][] testB = new int[0][];
        int[][] testC = new int[5][0];
        System.out.println(Arrays.deepToString(testC));
        System.out.println("testC[0] 長度：" + testC[0].length);
        
        int[][] testD = new int[][]{};
        System.out.println(Arrays.deepToString(testD));
        
        // int[][] testE = new int[][]{1, 2, 3};
        int[][] testF = new int[][]{{}, {}, {}, {}, {}};
        System.out.println(Arrays.deepToString(testF));
    }
    
}
