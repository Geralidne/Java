/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Circle cir = new Circle("圓形", "紅色");
        cir.setRadius(10);
        cir.draw();
        System.out.println("形狀：" + cir.getType());
        System.out.println("顏色：" + cir.getColor());
        System.out.println("半徑：" + cir.getRadius());
        System.out.printf("面積：%.2f%n", cir.getArea());        
        System.out.println("-------------------");
        
        Rectangle rect1 = new Rectangle("矩形", "綠色");
        rect1.setHeight(5);
        rect1.setWidth(6);
        rect1.draw();
        System.out.println("-------------------");
        
        Rectangle rect2 = new Rectangle("矩形", "藍色", 9, 8);
        rect2.draw();
        
    }
    
}
