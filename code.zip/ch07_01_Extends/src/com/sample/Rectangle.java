/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class Rectangle extends Shape{
    
    private double height, width;
    
    // 建構子多載
    public Rectangle(String type, String color) {
        super(type, color);
        System.out.println("連線資料庫...");
        System.out.println("驗證帳密...");
    }
    
    public Rectangle(String type, String color, double height, double width) {
        // super(type, color);
        // System.out.println("連線資料庫...");
        // System.out.println("驗證帳密...");
        // this([參數]) 呼叫自己的建構子
        // this([參數]) 必須寫在建構子的第一行
        this(type, color);
        setHeight(height);
        setWidth(width);
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    public void draw() {
        // super.XXX 呼叫父類別的物件成員 XXX
        super.draw();
        System.out.println("形狀：" + getType());
        System.out.println("顏色：" + super.getColor());
        System.out.println("高：" + height);
        System.out.println("寬：" + width);
        System.out.println("面積：" + getArea());        
    }  

    @Override
    public double getArea() {
        return height * width;
    }


    
    
    
}
