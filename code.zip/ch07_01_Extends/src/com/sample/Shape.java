/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */

// 自訂父類別，預設繼承 Object 類別
// 類別中如果有抽象方法，類別就必須宣告為抽象類別
// 抽象類別可以當作是一種規範
// 抽象類別不可以被實作(不可以被建立成物件)
public abstract class Shape {
    
    // 屬性
    // private 的成員子類別不可以直接使用
    private String type;
    private String color;
    
    // 建構子
    public Shape(String type, String color){
        System.out.println("Shape(type, color)...");
        this.type = type;
        this.color = color;
    }
    
    // 具體方法
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public void draw(){
        System.out.println("繪製圖形...");
    }
    
//    public double getArea(){
//        return 0.0;
//    }
    
    // 抽象方法：沒有具體內容的方法
    // 使用修飾字 abstract
    // 沒有{}，使用【;】結束
    // 抽象方法的具體內由子類別完成敘述(實作)
    // 語法：存取修飾字 abstract 方法型別 方法名稱(參數列);
    // 計算面積
    public abstract double getArea();
    
    
}
