/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
//           子類別  延伸     父類別
public class Circle extends Shape{
    
    // 子類別自己的屬性
    private double radius;
    
    // 建構子
    public Circle(String type, String color) {
        // super([參數]) 呼叫父類別建構子初始化
        // 若父類別建構子初始化時不需要參數，super() 可以省略不寫
        // 若父類別建構子初始化時需要參數，子類別必須撰寫 super(參數)，用 super() 來傳遞參數給父類別的建構子進行初始化
        // super() 必須寫在建構子的第一行
        super(type, color);
        System.out.println("Circle(type, color)...");
    }

    // 子類別自己的具體方法
    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    // 重新定義父類別的方法 Overriding Method(方法覆寫)
    // 當父類別的方法不適合子類別運作時，子類別可以重新定義父類別的方法(改寫方法的內容)
    // 在子類別宣告跟父類別相同的方法，執行時會以子類別為優先運作
    @Override
    public void draw() {
        System.out.println("繪製半徑 " + radius + " 的圓");
    }    
    
    // 實作父類別的抽象方法
    @Override
    public double getArea() {
        return Math.PI * Math.pow(radius, 2);
    }
    
    
}
