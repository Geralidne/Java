/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class MyPreparedStatement implements IEmployee{
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("ID：");
             
        int id = scanner.nextInt();
        System.out.println("---------------");
        
        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE ID=?";
        
        try(Connection conn = DriverManager.getConnection(url, user, password);
                PreparedStatement pstmt = conn.prepareStatement(sql)){
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()){
                System.out.println("ID：" + rs.getInt(ID)); 
                System.out.println("FirstName：" + rs.getString(FIRST_NAME));
                System.out.println("LastName：" + rs.getString(LAST_NAME));
                System.out.println("Bitrhday：" + rs.getString(BIRTHDAY));
                System.out.println("Salary：" + rs.getInt(SALARY));                
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
    
}
