/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public interface IEmployee {
    
    String url = "jdbc:derby://localhost:1527/EmployeeDB";
    String user = "app";
    String password = "app";
    
    String TABLE_NAME = "EMPLOYEE";
    String ID = "ID";
    String FIRST_NAME = "FIRSTNAME";
    String LAST_NAME = "LASTNAME";
    String BIRTHDAY = "BIRTHDAY";
    String SALARY = "SALARY"; 
}
