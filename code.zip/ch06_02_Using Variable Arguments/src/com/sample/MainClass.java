/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        average(10, 20);    // 編譯後：average(new int[]{10, 20});
        average(10, 20, 30);
        average(10, 20, 30, 40, 50);
        average(10, 20, 30, 40, 50, 60, 70, 80, 90, 100);
        
    }

    //                          可變動參數  
    private static void average(int... nums) { // 編譯後：private static void average(int[] nums) {...}
        int total = 0;
        for(int i : nums){
            total += i;
        }
        System.out.println("total：" + total);
        System.out.println("average：" + total/nums.length);
        System.out.println("----------------");
    }

    
}
