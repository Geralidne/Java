/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class Test { // 屬性 item 有效範圍開始
    
    // 方法
    public void setItem(String it){ // 參數 it 有效範圍開始
        System.out.println("it：" + it);
        
        // System.out.println("temp：" + temp); // temp 尚未宣告
        String temp = "[項目]" + it;   // 區域變數 temp 有效範圍開始
        System.out.println("temp：" + temp);
        item = "[工作]" + temp;
        System.out.println("item：" + item);        
        
    }// 參數 it 有效範圍結束、區域變數 temp 有效範圍結束
    
    public String getInfo(){
        // 嘗試使用 setItem() 中的參數 it
        // System.out.println("it：" + it);
        // 嘗試使用 setItem() 中的區域變數 temp
        // System.out.println("temp：" + temp);
        String temp = "Python";
        return item + "、" + temp;
    }
    
    
    // 屬性、欄位
    private String item;
}// 屬性 item 有效範圍結束
