/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import static com.sample.Department.HR;
import java.time.Month;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // API 中 Month
        System.out.println(Month.APRIL);
        
        System.out.println(Department.HR);
        System.out.println("--------------");
        // 呼叫列舉型別中 values() 會回傳一個該列舉型別的所有列舉值的陣列
        
        // 測試
        Department[] depts = Department.values();
        System.out.println("depts：" + Arrays.toString(depts));        
        
        System.out.println("代號查詢：");
        for(Department dept : depts){
            System.out.println(dept.ordinal() + "：" + dept); // ordinal() 回傳列哀列舉值的索引
        }
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("--------------\n-->");
        int dept = scanner.nextInt();
        switch(depts[dept]){
            case HR:
                System.out.println("HR department code：" + Department.HR.getDeptCode());
                break;
            case OPERATION:
                System.out.println("OPERATION department code：" + Department.OPERATION.getDeptCode());
                break;
            case LEGAL:
                System.out.println("LEGAL department code：" + Department.LEGAL.getDeptCode());
                break;
            case MARKETING:
                System.out.println("MARKETING department code：" + Department.MARKETING.getDeptCode());
                break;
                
        }
    }
    
}
