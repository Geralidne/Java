/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.HashSet;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Book book1 = new Book("Java SE 11", 600, 'J');
        System.out.println("book1：" + book1);
        System.out.println("book1：" + book1.toString());
        
        Book book2 = new Book("Python 3.9", 700, 'P');
        System.out.println("book2：" + book2);
        
        Book book3 = new Book("Java SE 11", 600, 'J');
        System.out.println("book3：" + book3);
        System.out.println("------------------------");
        
        // 比較物件用 == 是比較物件的記憶體位址
        System.out.println("book1 == book2：" + (book1==book2));
        System.out.println("book2 == book3：" + (book2==book3));
        System.out.println("book3 == book1：" + (book3==book1));
        System.out.println("------------------------");
        
        // 比較物件用 equals() 是比較物件的內容
        System.out.println("book1.equals(book2)：" + book1.equals(book2));
        System.out.println("book2.equals(book3)：" + book2.equals(book3));
        System.out.println("book3.equals(book1)：" + book3.equals(book1));
        System.out.println("------------------------");
        
        // 查詢物件的 HashCode
        System.out.println("book1：" + book1.hashCode());
        System.out.println("book2：" + book2.hashCode());
        System.out.println("book3：" + book3.hashCode());
        System.out.println("------------------------");
        
        // 建立 HashSet 集合，收集不重複的資料
        HashSet<Book> set = new HashSet();
        // 用 add() 將資料加入 set 集合中，加入成功回傳 true
        System.out.println("加入 book1：" + set.add(book1));
        System.out.println("加入 book2：" + set.add(book2));
        System.out.println("加入 book3：" + set.add(book3));
        // 查看 set 集合中的資料
        System.out.println(set);
        
        
    }
    
}
