/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.util.Objects;

/**
 *
 * @author User
 */
public class Book {
    private String name;
    private int price;
    private char type;

    public Book(String name, int price, char type) {
        this.name = name;
        this.price = price;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    // 重新定義父類別(Object) 的 toString() 方法
    @Override
    public String toString() {
        // return "Book{" + "name=" + name + ", price=" + price + ", type=" + type + '}';
        return "[" + name + ", " + price + ", " + type + ']';
    }

    // 重新定義 hashCode()
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.name);
        hash = 89 * hash + this.price;
        hash = 89 * hash + this.type;
        return hash;
    }

    // 重新定義 equals() 比較物件方法
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Book other = (Book) obj;
        if (this.price != other.price) {
            return false;
        }
        if (this.type != other.type) {
            return false;
        }
        return Objects.equals(this.name, other.name);
    }


    
    
    
}
