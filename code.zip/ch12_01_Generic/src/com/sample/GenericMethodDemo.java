/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class GenericMethodDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Integer[] intArray = {50, 10, 20, 100, 90};
        displayArray(intArray);
        
        String[] strArray = {"Java", "Python", "C#"};
        displayArray(strArray);
    }
    
    // 泛型方法
    public static <T> void displayArray(T[] inputArray){
        for(T element : inputArray){
            System.out.print(element + " | ");
        }
        System.out.println("\n------------------");
    }

//    private static void displayArray(Integer[] intArray) {
//        for(Integer element : intArray){
//            System.out.print(element + " | ");
//        }
//        System.out.println("\n------------------");
//    }
//
//    private static void displayArray(String[] strArray) {
//        for(String element : strArray){
//            System.out.print(element + " | ");
//        }
//        System.out.println("\n------------------");
//    }
    
}
