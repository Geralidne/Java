/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try(FileInputStream fis = new FileInputStream("test.txt")) {
            fis.read();
            System.out.println("讀取完成!");
            doTest();
        } catch (IOException | SQLException ex) {
            System.out.println(ex);
        } 
    }

    private static void doTest() throws SQLException {
        throw new SQLException("SQL 錯誤");
    }
    
}




/*

        public static void main(String[] args) {
        // TODO code application logic here
        FileInputStream fis = null;
        
        try {
            fis = new FileInputStream("test.txt");
            fis.read();
            System.out.println("讀取完成!");
            doTest();
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        } catch (IOException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }finally{
            if(fis != null){
                try {
                    fis.close();
                    System.out.println("檔案關閉!");
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
        }

*/
