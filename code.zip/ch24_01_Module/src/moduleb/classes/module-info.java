/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2SEModule/module-info.java to edit this template
 */

module moduleb {
    // exports package-name 將一個套件公開或導出給其他模組使用
    exports packageb1;
    
    // requires module-name 表示當前模組依賴於指定的模組
    requires modulec;
    
    // requires transitive module-name 表示任何需要當前模組的其他模組也將依賴於 module-name
    // requires transitive modulec;
 
}
