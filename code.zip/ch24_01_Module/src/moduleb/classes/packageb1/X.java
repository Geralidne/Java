/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package packageb1;

import packageb2.Z;
import packagec.K;

/**
 *
 * @author User
 */
public class X {

    @Override
    public String toString() {
        System.out.println("--- X start ---");
        Y y = new Y();
        System.out.println(y);
        
        Z z = new Z();
        System.out.println(z);
        
        K k = new K();
        System.out.println(k);
        
        System.out.println("--- X end ---");
        return "moduleb - paclageb1 - X.java";
    }
    
}
