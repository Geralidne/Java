/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package packagea;

import packageb1.X;

/**
 *
 * @author User
 */
public class MainClass {
    
    public static void main(String[] args) {
        X x = new X();
        System.out.println(x);
        
       
        // Y y = new Y();
        // Z z = new Z();
        // K k = new K();
        
    }
}
