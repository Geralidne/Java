/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2SEModule/module-info.java to edit this template
 */

module modulea {
    
    // requires module-name 表示當前模組依賴於指定的模組
    requires moduleb;
    
    // requires modulec;
}
