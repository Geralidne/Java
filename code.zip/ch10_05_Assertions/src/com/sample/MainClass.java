/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        System.out.print("輸入一個正整數：");
        int input = scanner.nextInt();
        doTest(input);
    }

    private static void doTest(int input) {
        if(input > 0){
            System.out.println("輸入的值是正整數：" + input);
        }else if(input == 0){
            System.out.println("輸入的值是：" + input);
        }else{
            System.out.println("輸入的值是負數：" + input);
            assert input >= 0 : "輸入的值小於 0!";
        }
    }
    
    
    
}
