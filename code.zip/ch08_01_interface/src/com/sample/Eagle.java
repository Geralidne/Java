/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
// 實作介面         implements 介面名稱1, 介面名稱2, 介面名稱3, ...
public class Eagle implements Fly  {
    
    private String name;

    public Eagle(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }   
    
    // 實作介面中的抽象方法
    @Override
    public void flying() {
        System.out.println(name + " 在飛");
        System.out.println("a：" + a);
        System.out.println("速度：" + (FlySpeed.SPEED + MoveSpeed.SPEED));
    }
    
}
