/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public interface Fly extends FlySpeed, MoveSpeed{
    
    // 常數(final)屬性
    // private int a = 10;  // 介面中的屬性沒有 private ，都是 public
    // public int b;  // 介面中的屬性都是 finall，已經明確指定值
    int a = 10;       // 編譯後：public static final int a = 10;
    
    // 沒有建構子
    
    // 沒有具體方法
    // void show(){}
    
    // 抽象方法
    void flying();  // 編譯後：public abstract void flying();
    
    // Java 7.0 前
    //-------------------------------------------------------------
    // Java 8.0 開始
    // default 方法
    // static 方法    
    
    // Java 9.0 開始
    // private 方法
    
    
    
}
