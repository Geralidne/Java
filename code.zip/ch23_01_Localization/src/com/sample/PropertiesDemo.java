/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class PropertiesDemo {
    
    public static void main(String[] args) {
        
        Properties myProps = new Properties();
        
        try(FileInputStream fis = new FileInputStream("ServerInfo.properties")){
            
            myProps.load(fis);
            System.out.println("Server：" + myProps.getProperty("hostName"));
            System.out.println("User：" + myProps.getProperty("userName"));
            System.out.println("Password：" + myProps.getProperty("password"));
            System.out.println("IP Address：" + myProps.getProperty("ip"));
            
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
