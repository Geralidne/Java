/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class LocalizationDemo {
    
    public static void main(String[] args) {
        // 各國語言(語系)代碼表：https://hoohoo.top/blog/national-language-code-table-zh-tw-zh-cn-en-us-json-format/
        // 使用 ket = value 建立資料，key 是自訂名稱
        
        Scanner scanner = new Scanner(System.in);
        String keyin = "";
        while(!keyin.toUpperCase().equals("Q")){
            System.out.print("C)中文 E)English F)Français J)日本　Q)Quit：");
            keyin = scanner.next().toUpperCase();
            switch(keyin){
                case "C":
                    display(new Locale("zh", "TW"));
                    break;
                case "E":
                    display(Locale.US);
                    break;
                case "F":
                    display(new Locale("fr", "FR"));
                    break;
                case "J":
                    display(new Locale("ja", "JP"));
                    break;
                case "Q":
                    System.out.println("結束");
                    break;
                default:
                    display(Locale.getDefault());
            }
        }
    }
    
    private static void display(Locale locale){
        System.out.println("Local：" + locale.toString());
        ResourceBundle res = ResourceBundle.getBundle("Message", locale);
        System.out.println(res.getString("say") + "! " + res.getString("tw"));
        
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(locale);
        System.out.println(now.format(dtf));
        
        double number = 1_234_567.89;
        NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
        System.out.println(nf.format(number));
        System.out.println("-------------------------------");
    }
    
}
