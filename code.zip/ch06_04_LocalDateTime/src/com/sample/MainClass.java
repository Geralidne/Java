/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.chrono.JapaneseDate;
import java.time.chrono.MinguoDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // 建立日期
        LocalDate date1 = LocalDate.now();
        System.out.println("date1：" + date1);
        LocalDate date2 = LocalDate.of(2023, 2, 28);
        System.out.println("date2：" + date2);
        LocalDate date3 = LocalDate.of(2023, Month.APRIL, 23);
        System.out.println("date3：" + date3);
        LocalDate date4 = LocalDate.parse("2023-06-30");   // yyyy-mm-dd
        System.out.println("date4：" + date4);
        System.out.println("年：" + date1.getYear());
        System.out.println("月：" + date1.getMonthValue());
        System.out.println("月(英文)：" + date1.getMonth());
        System.out.println("日：" + date1.getDayOfMonth());
        System.out.println("星期：" + date1.getDayOfWeek());
        System.out.println("今年的第幾天：" + date1.getDayOfYear());
        System.out.println("-----------------------------");
        
        // 建立時間
        LocalTime time1 = LocalTime.now();
        System.out.println("time1：" + time1);
        LocalTime time2 = LocalTime.of(16, 26);
        System.out.println("time2：" + time2);
        LocalTime time3 = LocalTime.of(16, 26, 36);
        System.out.println("time3：" + time3);
        LocalTime time4 = LocalTime.of(16, 26, 50, 135);  // 時、分、秒、奈秒
        System.out.println("time4：" + time4);
        System.out.println("時：" + time1.getHour());
        System.out.println("分：" + time1.getMinute());
        System.out.println("秒：" + time1.getSecond());
        System.out.println("奈秒：" + time1.getNano());
        System.out.println("-----------------------------");
        
        // 建立日期時間
        LocalDateTime datetime1 = LocalDateTime.now();
        System.out.println("datetime1：" + datetime1);
        LocalDateTime datetime2 = LocalDateTime.of(2023, 4, 23, 16, 32, 5);
        System.out.println("datetime2：" + datetime2);
        System.out.println("-----------------------------");
        
        // 格式化
        System.out.println("日期:" + datetime1.format(DateTimeFormatter.ISO_DATE));
        System.out.println("時間:" + datetime1.format(DateTimeFormatter.ISO_TIME));
        System.out.println("------");
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)));
        System.out.println("------");
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.LONG)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)));
        System.out.println("------");
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)));
        System.out.println(datetime1.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)));
        System.out.println("-----------------------------");
        
        // 計算
        System.out.println(date1.minusDays(45));
        System.out.println(date1.plusDays(45));
        System.out.println(date1.plusMonths(3).plusWeeks(2).plusDays(4));
        
        // 曆法
        MinguoDate minguoDate = MinguoDate.now();
        System.out.println("minguoDate：" + minguoDate);
        JapaneseDate japaneseDate = JapaneseDate.now();
        System.out.println("japaneseDate：" + japaneseDate);
        System.out.println("-----------------------------");
        
        // 常用方法
        System.out.printf("%s isAfter %s：%b%n", date1, date2, date1.isAfter(date2));
        System.out.printf("%s isAfter %s：%b%n", date1, date4, date1.isAfter(date4));
        
        System.out.printf("%s isBefore %s：%b%n", date1, date2, date1.isBefore(date2));
        System.out.printf("%s isBefore %s：%b%n", date1, date4, date1.isBefore(date4));
        
        System.out.printf("%s isEqual %s：%b%n", date1, date2, date1.isEqual(date2));
        System.out.printf("%s isEqual %s：%b%n", date1, date3, date1.isEqual(date3));
        
        System.out.printf("%s 年 isLeapYear：%b%n", date1.getYear(), date1.isLeapYear());
        System.out.printf("2024 年 isLeapYear：%b%n", LocalDate.of(2024, 1, 1).isLeapYear());

        
        
        
    }
    
}
