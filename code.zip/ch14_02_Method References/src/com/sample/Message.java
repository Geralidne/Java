/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
@FunctionalInterface
public interface Message {
    // 設計一個抽象方法，這個方法會回傳一個 Print 型別的物件
    Print getMessage(String msg);
}

/*
不用執行，用來說明 Message 介面中的 getMessage() 抽象方法被實作的語法
public Print getMessage(String msg){
    return new Print(msg);
}
*/

//-----------------------------
class Print{
    // 建構子
    public Print(String str){
        System.out.println("Print 物件建立了! str：" + str);
    }
}

