/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.List;
import java.util.function.Consumer;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List<String> list = List.of("java", "python", "android", "mysql");
        // 簡易方式
        System.out.println("list：" + list);
        System.out.println("--------------------");
        
        // 使用增強型迴圈
        for(String s : list){
            System.out.println(s);
        }
        System.out.println("--------------------");
        
        // 使用 lambda + forEach
        Consumer<String> action = s -> System.out.println(s);
        list.forEach(action);
        System.out.println("--------------------");
        list.forEach(s -> System.out.println(s));
        System.out.println("--------------------");
        
        // 使用 Method Referance(方法參照)：lambda 語法中只呼叫一個方法
        list.forEach(System.out::println);
        System.out.println("--------------------");
        
        // 呼叫 Test 類別中 static 方法
        list.forEach(s -> Test.staticMethod(s));
        System.out.println("\n--------------------");
        list.forEach(Test::staticMethod);
        System.out.println("\n--------------------");
        
        // 呼叫 Test 類別中物件成員方法
        // 必須先建立物件
        Test t = new Test();
        list.forEach(s -> t.instanceMethod(s));
        System.out.println("\n--------------------");
        list.forEach(t::instanceMethod);
        System.out.println("\n--------------------");
        
        Message msg1 = s -> new Print(s);
        msg1.getMessage("Hello!");
        System.out.println("----------------------");
        
        // Reference to a constructor
        Message msg2 = Print::new;
        msg2.getMessage("Hello!");
        
        
        
        
        
        
    }
    
}
