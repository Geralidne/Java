/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import static java.lang.System.out;
import static java.lang.Math.*;
import java.util.Random;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // 建立 Book 物件並觀察 bookId 流水號
        Book book1 = new Book("java se 11", 'J');
        Book book2 = new Book("python 3.9", 'P');
        Book book3 = new Book("android 12", 'A');
        
        // 由物件呼叫物件成員
        book1.info();
        // 由物件呼叫類別成員
        book1.showId();
        out.println("-----------------");
        
        // 如何直接呼叫類別成員?
        // 類別名稱.類別成員名稱
        Book.showId();
        out.println("id：" + Book.id);
        out.println("-----------------");
        
        // 呼叫 API 現成的類別成員
        out.println("int 最大值：" + Integer.MAX_VALUE);
        out.println("PI：" + PI);
        out.println("3 的 5 次方：" + pow(3, 5));
        out.println("Math.random() 產生 0.0 ~ 1.0(不包含)亂數：" + random());
        // 比較
        Random random = new Random();
        out.println("random.nextDouble() 產生 0.0 ~ 1.0(不包含)亂數：" + random.nextDouble());
        out.println("-----------------");
        
        // main() 是 static 類別成員，要呼叫同類別中的其他方法
        // 呼叫物件成員方法 
        // int max = getMax(3, 8);  // non-static method getMax(int,int) cannot be referenced from a static context
        // 因為 main() 方法是類別成員，類別成員只能【直接】呼叫【類別成員屬性或類別成員方法】
        // 若要呼叫物件成員，必須先將物件成員所在的類別先建立物件再呼叫
        MainClass mainclass = new MainClass();
        int max = mainclass.getMax(3, 8);
        out.println("3 和 8 的最大值：" + max);
        out.println("-----------------");
        
        // 呼叫類別成員方法 
        double sum = sum(2.0, 6.0);  // 類別成員 main() 可以直接呼叫類別成員 sum()
        out.println("2.0 + 6.0 = " + sum);
        
        
        
    }// main() 結束
    
    // 物件成員方法
    private int getMax(int a, int b){
        return a > b ? a : b;  // 三元運算子  判別式 ? 成立時 : 不成立時
    }
    
    // 類別成員(static)
    private static double sum(double x, double y){
        return x + y;
    }
    
}
