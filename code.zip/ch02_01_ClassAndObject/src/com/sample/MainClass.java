/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // 建立物件
        // 類別型別 參考名稱 = new 建構子()
        Book book1 = new Book();
        
        // 操作物件
        // 參考名稱.物件成員名稱
        book1.name = "Java SE 11";
        book1.price = 700;
        System.out.println("book1：");
        book1.display();
        System.out.println("---------------");
        
        // 使用 Book 類別建立第二個物件
        Book book2 = new Book();
        book2.name = "Python 3.9";
        book2.price = 600;
        System.out.println("book2：");
        book2.display();
        System.out.println("---------------");
        
        System.out.println("查看物件的記憶體位址：");
        System.out.println("book1：" + System.identityHashCode(book1));
        System.out.println("book2：" + System.identityHashCode(book2));
        System.out.println("---------------");
        
        // 宣告區域變數
        int sum = book1.price + book2.price;
        System.out.println("總售價：" + sum);
        System.out.println("---------------");
        
        // 將 book2 的資料指定給 book3
        // 物件建立後是否可以給多個參考共用?【yes】
        Book book3 = book2;
        System.out.println("book3：" + System.identityHashCode(book3));
        book3.price = 800;
        System.out.println("book3 售價更改後...");
        System.out.println("book2：");
        book2.display();
        System.out.println("book3：");
        book3.display();
        System.out.println("---------------");
        
        // 將 book3 的資料指定給 book1
        // book1 參考原本指向 Java SE 11 物件，是否可以改指向 python 3.9 物件?【yes】
        book1 = book3;
        System.out.println("book1：" + System.identityHashCode(book1));
        System.out.println("book1：");
        book1.display();
        System.out.println("---------------");
        
        // 將 null(無、空，是參考型別的預設值)指派給 book2
        book2 = null;  // book2 沒有指向任何物件
        // book2.display();  // 執行期錯誤：NullPointerException
        System.out.println("book2：" + System.identityHashCode(book2));
        
    }
    
}
