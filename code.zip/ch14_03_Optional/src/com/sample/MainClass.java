/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.NoSuchElementException;
import java.util.Optional;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("1. " + averageWithNull());
        System.out.println("2. " + averageWithNull(90, 80, 100, 95));
        System.out.println("------------------");
        charWithNull();
        System.out.println("------------------");
        
        // Optional<Double> opt1 = averageWithOptional();
        Optional<Double> opt1 = averageWithOptional(90, 80, 100, 95);
        System.out.println("opt1：" + opt1);
        
        if(opt1.isPresent()){  // 是否有回傳物
            System.out.println("3. opt1：" + opt1.get());  // 取出內容物
        }else{
            System.out.println("3. opt1：is empty");
        }
        System.out.println("-------------------");
        
        opt1.ifPresent(d -> System.out.println("4. opt1：" + d));
        System.out.println("-------------------");
        
        Optional<Double> opt2 = averageWithOptional();
        try{
            System.out.println("5. opt2：" + opt2.get());
        }catch(NoSuchElementException ex){
            System.out.println("5. opt2：" + ex.getMessage());
        }
        System.out.println("-------------------");   
        
        System.out.println("6. opt1：" + opt1.orElse(Double.NaN));
        System.out.println("6. opt2：" + opt2.orElse(Double.NaN));
        System.out.println("6. opt2：" + opt2.orElse(0.0));

    }
    
    private static Double averageWithNull(int... scores){
        if(scores.length == 0){
            return null;
        }
        
        double sum = 0.0;
        for(int score : scores){
            sum += score;
        }
        return sum / scores.length;
    }
    
    private static void charWithNull(){
        char[] charArray = {'J', 'a', 'v', 'a'};
        String s1 = null;
        for(char c : charArray){
            s1 = s1 + c;
        }
        System.out.println("s1：" + s1);
        Object o = null;
        System.out.println("o：" + o);
        // System.out.println(null);  // 編譯失敗，null 不屬於任何型別，不能通過編譯
        
    }
    
    private static Optional<Double> averageWithOptional(int... scores){
        if(scores.length == 0){
            return Optional.empty();  // 無參數輸入，回傳空的 Optional 物件
        }
        
        double sum = 0.0 ;
        for(int score : scores){
            sum += score;
        }
        return Optional.of(sum / scores.length); // 有參數輸入，回傳內含 Double 型態的平均值的 Optional 物件
    }
    
}


