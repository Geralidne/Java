/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class SerializeDemo {
    
    public static void main(String[] args) {
        Student student = new Student("Lisa");
        student.calScores(100, 99, 88, 99);
        System.out.println(student);
        System.out.println("-------------------");
        
        //  序列化
        try(FileOutputStream fos = new FileOutputStream("lisa.student");
                ObjectOutputStream oos = new ObjectOutputStream(fos)){
            oos.writeObject(student);
            System.out.println("儲存成功!");
        } catch (IOException ex) {
            System.out.println(ex);
        }
        System.out.println("-------------------");
        
        // 反序列化
        try(FileInputStream fis = new FileInputStream("lisa.student");
                ObjectInputStream ois = new ObjectInputStream(fis)){
            Student s = (Student)ois.readObject();
            System.out.println("名字：" + s.getName());
            System.out.println("成績：" + s.getSum());
            System.out.println("平均：" + s.getAverage());
            System.out.println("日期：" + s.getDatetime());
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex);
        }
    }
    
}
