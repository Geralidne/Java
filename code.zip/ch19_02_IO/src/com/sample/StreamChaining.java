/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class StreamChaining {

    private static void writerText(File file, String[] temps) {
        try(FileWriter fw = new FileWriter(file, true);
               BufferedWriter bw = new BufferedWriter(fw)){
            for(String s : temps){
                bw.write(s);
                bw.newLine();
            }
            bw.write("-----------------------");
            bw.newLine();
            System.out.println("資料輸出成功!");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    private static void readerText(File file) {
        try(FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr)){
            String line;
            while((line = br.readLine()) != null){
                System.out.println(line);
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
    
    enum Menu{
        登入, 查詢, 結束
    }
    
    public static void main(String[] args) {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        
//        System.out.print("西元：");
//        try {
//            System.out.println(Integer.parseInt(br.readLine()) - 1911);
//        } catch (IOException ex) {
//            System.out.println(ex);
//        }

        File file = new File("log.txt");
        
        try {
            outer:{ // 標籤
                do{
                    for (int i = 0; i < Menu.values().length; i++) {
                        System.out.println((i + 1) + ". " + Menu.values()[i]);
                    }
                    System.out.println("-----------");
                    System.out.print("### ");
                    String input = br.readLine();
                    // System.out.println(input);
                    switch(input){
                        case "1":
                            // System.out.println("登入");
                            String[] temps = new String[3];
                            System.out.print("ID：");
                            temps[0] = br.readLine();
                            System.out.print("password：");
                            temps[1] = br.readLine();
                            temps[2] = LocalDateTime.now().toString();
                            writerText(file, temps);
                            break;
                        case "2":
                            System.out.println("查詢");
                            readerText(file);
                            break;
                        case "3":
                            System.out.println("結束!");
                            break outer;
                        default:
                            System.out.println("選項輸入錯誤!");
                    }
                    System.out.println("----------------");
                }while(true);
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
        

        
    }
    
}
