/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class ByteStreams {
    
    public static void main(String[] args) {
        // 建立檔案物件
            File file = new File("test.txt");
            writerText(file);
            System.out.println("-----------------");
            readerText(file);
    }

    // 輸出資料到檔案
    private static void writerText(File file) {
        String temp = "Byte Streams 位元處理，2023-06-04";
        FileOutputStream fos = null;
        
        try {
            fos = new FileOutputStream(file);
            fos.write(temp.getBytes());
            System.out.println("檔案寫入完成!");
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        } catch (IOException ex) {
            System.out.println(ex);
        } finally{
            if(fos != null){
                try {
                    fos.close();
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
        }
    }

    // 從檔案讀取資料
    private static void readerText(File file) {
        try(FileInputStream fis = new FileInputStream(file)){
            System.out.println("檔案大小：" + fis.available() + " 位元組");
            int read;
            while((read = fis.read()) != -1){
                System.out.print((char)read);
            }
            System.out.println("\n檔案讀取完成");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
