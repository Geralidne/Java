/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author User
 */
public class Student implements Serializable{
    
    // 定義物件保存版本編號
    private static long serialVersionUID = 1L;
    
    private String name;
    private int sum;
    private transient double average;
    private transient LocalDateTime datetime = LocalDateTime.now();
    
    public Student(String name){
        this.name = name;
    }
    
    public void calScores(int... scores){
        for(int i : scores){
            sum += i;
        }
        average = (double)sum / scores.length;
    }

    public String getName() {
        return name;
    }

    public int getSum() {
        return sum;
    }

    public double getAverage() {
        return average;
    }

    public LocalDateTime getDatetime() {
        return datetime;
    }

    @Override
    public String toString() {
        return "Student{" + "name=" + name + ", sum=" + sum + ", average=" + average + ", datetime=" + datetime + '}';
    }
    
    
    
    
    
}
