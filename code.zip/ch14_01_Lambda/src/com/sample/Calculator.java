/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
// 先輸入 @Func 再按 <CTRL> + <\>
@FunctionalInterface
public interface Calculator {
    double cal(double a, double b);
}
