/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CTest ct = new CTest();
        ct.display();
        System.out.println("---------");

        ITest it1 = new CTest();
        it1.display();
        System.out.println("---------");

        // 建立 匿名內部類別
        // new <interface-name or class-name> (<argument-list>) {
        //      Anonymous class body goes here
        // }
        
        // 使用匿名內部類別實作 display()
        ITest it2 = new ITest() {
            @Override
            public void display() {
                System.out.println("匿名內部類別 display()...");
            }
        };
        it2.display();
        System.out.println("---------");
        
        /*
        Lambda運算式
        input -> body
        ------------------------------------------
        input 無參數：      () ->
        input 一個參數a：    a ->    
        input 多個參數a,b(加型別)：   (int a, int b) ->
        input 多個參數a,b(省略型別)： (a, b)->
        ------------------------------------------
        body 什麼事不做：       -> {}
        body 單行無回傳值：     -> System.out.println(...);
        body 多行無回傳值：     -> { System.out.println(...);
                                   System.out.println(...);
                                   ... }    
        body 單行有回傳值：     -> a+b;
        body 多行有回傳值：     ->{ ...
                                  ...
                                  return a+b; }

        */
        // 使用 lambda 表達式實作 ITest 介面中的 display() 抽象方法
        ITest it3 = () -> System.out.println("lambda display()...");
        it3.display();
        System.out.println("---------");
        
        Calculator cal_1 = (double a, double b) -> {System.out.println("a：" + a);
                                                    System.out.println("b：" + b);
                                                    return a + b;};
        System.out.println("5 + 6 = " + cal_1.cal(5, 6));
        
        Calculator cal_2 = (x, y) -> x * y;
        System.out.println("5 * 6 = " + cal_2.cal(5, 6));
        
    }
}
