/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MyClass implements InterfaceA{

    // Java 7 寫法 實作抽象方法
//    @Override
//    public void doThis(int i) {
//        System.out.println("doThis：" + i);
//    }

//    @Override
//    public void doThat(int i) {
//        System.out.println("doThat：" + i);
//        System.out.println("show doThat");
//    }
    //----------------------------------------------
    // Java 8 寫法 使用 default 方法
    
}
