/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public interface InterfaceA {
    
    // Java 7 寫法 使用抽象方法
    // void doThis(int i);
    // void doThat(int i);
    //--------------------------------------------
    
    // Java 8 寫法 使用 default 方法
    public default void doThis(int i) {
        // System.out.println("default method：" + i);
        // Java 9 新增呼叫 private 方法
        test(i);
    }
    
    public default void doThat(int i) {
        // System.out.println("default method：" + i);
        // Java 9 新增呼叫 private 方法
        test(i);
        System.out.println("show default method");
    }
    
    // Java 9.0 新增 private 方法
    private void test(int i){
        System.out.println("default method：" + i);
    }
}
